package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NegativeTestCases {
	
	WebDriver driver;
	// Setup*************
	@BeforeTest (alwaysRun = true)
	public void setUp()
	{
	// Set system path for browser driver
	System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

	// Open Browser
	driver = new ChromeDriver();
	}
	

	@Test  (groups={"Regression"})
	public void invalidLogin() {
	// Open URL
	driver.get("http://zero.webappsecurity.com/");

	driver.manage().window().maximize();

	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	SoftAssert sa= new SoftAssert();

	driver.findElement(By.tagName("button")).click();

	driver.findElement(By.name("user_login")).sendKeys("usernam");

	driver.findElement(By.cssSelector("i.icon-question-sign")).click();

	driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");

	driver.findElement(By.name("submit")).click();

	driver.findElement(By.id("details-button")).click();

	driver.findElement(By.id("proceed-link")).click();

	sa.assertEquals(driver.getTitle(), "Zero - Account Summary", "Test Failed");

	sa.assertAll();
	}
	
	@Test (groups= {"Regression"})
	public void invalidUsername() {
		// Open URL
		driver.get("http://zero.webappsecurity.com/");

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		SoftAssert sa= new SoftAssert();

		driver.findElement(By.tagName("button")).click();

		driver.findElement(By.name("user_login")).sendKeys(" ");

		driver.findElement(By.cssSelector("i.icon-question-sign")).click();

		driver.findElement(By.cssSelector("[type='password']")).sendKeys("  ");

		driver.findElement(By.name("submit")).click();

		driver.findElement(By.id("details-button")).click();

		driver.findElement(By.id("proceed-link")).click();

		sa.assertEquals(driver.getTitle(), "Zero - Account Summary", "Test Failed");

		sa.assertAll();
		}
	

	@Test(groups= {"Regression"})
	public void LoginTest()
	{
	// Open URL
	driver.get("http://zero.webappsecurity.com/");

	driver.manage().window().maximize();

	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	SoftAssert sa= new SoftAssert();

	sa.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards1", "Test Failed");

	sa.assertAll();

	}
	
	@Test(groups= {"Regression"})
	
	public void ForgotPage()
	{
	// Open URL
	driver.get("http://zero.webappsecurity.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	SoftAssert sa= new SoftAssert();
	driver.findElement(By.linkText("Forgot your password ?")).click();
	sa.assertEquals(driver.getTitle(), "Zero - Forgotten Password1", "Test Failed");

	sa.assertAll();
	}
	
	@Test (groups= {"Regression"})
	
	public void HomePage()
	{
	// Open URL
	driver.get("http://zero.webappsecurity.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	SoftAssert sa= new SoftAssert();
	driver.findElement(By.tagName("button")).click();
	driver.findElement(By.name("user_login")).sendKeys("username");
	driver.findElement(By.cssSelector("i.icon-question-sign")).click();
	driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
	driver.findElement(By.name("submit")).click();
	driver.findElement(By.id("details-button")).click();
	driver.findElement(By.partialLinkText("Proceed to zero")).click();
	
	String textverify=driver.findElement(By.xpath("//h2[contains(text(),'Cash Accounts')]")).getText();

	Assert.assertEquals(textverify, "Cash Accounts1");

	sa.assertAll();
	
	}


	 //********CleanUp*************************
	@AfterTest (alwaysRun = true)
	public void cleanUp()
	{
	// Close Browser
	driver.close();
	// Kill Browser
	driver.quit();
	}
}
