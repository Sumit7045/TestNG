package test;


import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PositiveTestCases {
	
	WebDriver driver;
	// Setup*************
	@BeforeTest (alwaysRun = true)
	public void setUp()
	{
	// Set system path for browser driver
	System.setProperty("webdriver.chrome.driver", "C:\\SeleniumBrowserDrivers\\chromedriver.exe");

	// Open Browser
	driver = new ChromeDriver();
	}
	
	@Test  (groups = {"Smoke"})
	//*********Test************************
	public void LoginTest() throws InterruptedException
	{
	// Open URLS
	driver.get("http://zero.webappsecurity.com/");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Test Failed");

	driver.findElement(By.tagName("button")).click();
	driver.findElement(By.name("user_login")).sendKeys("username");
	driver.findElement(By.cssSelector("i.icon-question-sign")).click();
	driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
	
	 //click on a checkbox
    WebElement rememberMeCheckbox = driver.findElement(By.id("user_remember_me"));

    boolean rmcIsSelected = rememberMeCheckbox.isSelected();
    boolean rmcIsdisplyed = rememberMeCheckbox.isDisplayed();
    boolean rmcIsEnabled = rememberMeCheckbox.isEnabled();

    if (rmcIsdisplyed) {
        System.out.println("Checkbox is displyed!");
        if (rmcIsEnabled) {
            System.out.println("Checkbox is Enabled");
            if (rmcIsSelected) {
                System.out.println("Checkbox is Selected");                   
            } else {
                rememberMeCheckbox.click();
                System.out.println("Checkbox was not checked. I have checked it now!");
            }
        } else {
            System.out.println("Checkbox is not Enabled. Cannot do anything further!");
        }
    } else {
        System.out.println("Checkbox is NOT displyed!!!");
    }
    
    driver.findElement(By.name("submit")).click();
	driver.findElement(By.id("details-button")).click();
	driver.findElement(By.partialLinkText("Proceed to zero")).click();
	Thread.sleep(3000);
	driver.findElement(By.xpath("//a[contains(text(),'Pay Bills')]")).click();
	driver.findElement(By.xpath("//a[contains(text(),'Purchase Foreign Currency')]")).click();
	
	//Explicit Wait
	WebDriverWait wait1 = new WebDriverWait(driver, 10);
	wait1.until(ExpectedConditions.titleContains("Zero - Pay Bills"));
	
	driver.findElement(By.id("purchase_cash")).click();
	
	Alert ZbAlert = driver.switchTo().alert();
	String Alert = ZbAlert.getText();
    System.out.println("The text on Zb alert is = '" + Alert + "'");
    
    ZbAlert.accept();
    WebDriverWait wait2 = new WebDriverWait(driver, 10);
     // Logging Out
	driver.findElement(By.xpath("//body/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[3]/a[1]")).click();
	driver.findElement(By.id("logout_link")).click();
	
	Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
		
	}
	
	@Test  (groups = {"Smoke"})
	public void TransferFunds() throws InterruptedException {
		driver.get("http://zero.webappsecurity.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards", "Test Failed");

		driver.findElement(By.tagName("button")).click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.cssSelector("i.icon-question-sign")).click();
		driver.findElement(By.cssSelector("[type='password']")).sendKeys("password");
		
		 //click on a checkbox
	    WebElement rememberMeCheckbox = driver.findElement(By.id("user_remember_me"));

	    boolean rmcIsSelected = rememberMeCheckbox.isSelected();
	    boolean rmcIsdisplyed = rememberMeCheckbox.isDisplayed();
	    boolean rmcIsEnabled = rememberMeCheckbox.isEnabled();

	    if (rmcIsdisplyed) {
	        System.out.println("Checkbox is displyed!");
	        if (rmcIsEnabled) {
	            System.out.println("Checkbox is Enabled");
	            if (rmcIsSelected) {
	                System.out.println("Checkbox is Selected");                   
	            } else {
	                rememberMeCheckbox.click();
	                System.out.println("Checkbox was not checked. I have checked it now!");
	            }
	        } else {
	            System.out.println("Checkbox is not Enabled. Cannot do anything further!");
	        }
	    } else {
	        System.out.println("Checkbox is NOT displyed!!!");
	    }
	    
	    driver.findElement(By.name("submit")).click();
		
		driver.findElement(By.xpath("//a[contains(text(),'Transfer Funds')]")).click();
		Thread.sleep(3000);
		
		WebElement dropDown= driver.findElement(By.id("tf_fromAccountId"));
		Select sel= new Select(dropDown);
		sel.selectByVisibleText("Savings(Avail. balance = $ 1000)");
		driver.findElement(By.xpath("//input[@id='tf_amount']")).sendKeys("500");
		driver.findElement(By.tagName("button")).click();
		
		 // Logging Out
		driver.findElement(By.xpath("//body/div[1]/div[1]/div[1]/div[1]/div[1]/ul[1]/li[3]/a[1]")).click();
		driver.findElement(By.id("logout_link")).click();
		
		Assert.assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
	}
	   //********CleanUp*************************
		@AfterTest (alwaysRun = true)
		public void cleanUp()
		{
		// Close Browser
		driver.close();
		// Kill Browser
		driver.quit();
		}
}
